# v1.3.2 public source-only archive

Original author: TopCat Romhacking. Snapshot: October 20, 2026.

This is a **publicly shareable derivative** of the original experimental ZIP. It excludes the three console-specific CSV files originally under `PC_ONLY/PRIVATE/` (installed titles, DB audit and selected-game preview). The original exact ZIP is retained only in the private `romhacking` preservation repository.

This package includes the optional read-only WUPS attestation module, marker, source scripts, source headers, tests and safety documentation. There is **no tested multi-profile installer, no approved live Barista/allowlist deployment and no evidence of on-console v1.3.2 attestation yet**. Follow README and transaction safety gate. All menu and save data require private, user-provided backups; never upload them to a public issue or repo.

The included PC-only preflight gate needs private v1.0 inventory, v1.1.1 audit and v1.2 preview CSV files, referenced in the README as placeholders under `/PC/user-private/`. Those files are NOT included here and must come from the owner.

Full original ZIP SHA-256 (private copy): `ef6c2ee6eb6836a204df84fa23ab3d3155503ea09fd79df846a5424744a36d3e`.
