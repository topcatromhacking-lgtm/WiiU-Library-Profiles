Wii U Library Profiles v1.3.2: ACTIVE-SAVE ATTESTATION
==================================================
EXPERIMENTAL. NO LIVE BARISTA/ALLOWLIST DEPLOYMENT.

Changes since v1.3.1:
  1. OPTIONAL Wii U Menu-side, one-shot read-only inspection of the redirected
     Barista candidate file for CURRENT nn::act persistent ID 80000001.
  2. SHA-256 of full file, fixed first 15 game/user icons, and preserved
     root metadata/folder suffix; strict root + 60-folder consistency scan.
  3. PC-only double-copy preflight gate, requiring exact match to the Menu
     report and hardware-validated 277-game preview, 511-game inventory,
     and 284-ID WLPA pair. NO INSTALLABLE OUTPUTS.
  4. 33 Python tests, portable C structure tests and WUT/WUPS cross-build pass.

DO NOT install multiple Library Profiles WUPS at the same time.
DO NOT replace BaristaAccountSaveFile.dat, any allowlist or v08 config.
DO NOT use Menu Sort Aroma during this controlled test.
DO NOT edit or disable SDUSB, NAND or another account (especially 80000009).

FILES TO TEST (ONLY OPTIONAL WUPS + MARKER)
 - OPTIONAL_WUPS/wiiu_library_profiles_v132_save_attest.wps
 - OPTIONAL_MARKER/ENABLE-V132-ATTEST.txt

PHASE 1: SAFE PLUGIN BOOT WITHOUT NEW MARKER
  1. Power OFF console; safely access SD card from PC and back up working WUPS,
     Barista save, both allowlists, active-profile.cfg and v08 markers.
  2. Remove old Library Profiles .wps from
       sd:/wiiu/environments/aroma/plugins/
     (keep backup on PC). Install ONLY v132_save_attest.wps there.
  3. Do NOT add ENABLE-V132-ATTEST.txt yet. Leave existing
     ENABLE-V08-EXPERIMENT.txt and the original profile/allowlists untouched.
     Temporarily remove optional v10/v11/v12 diagnostic markers to isolate test.
  4. Boot Wii U, verify your CURRENT Wii U/NES active profile still works.
     On any error: power OFF and restore old WUPS. Do not proceed.

PHASE 2: OPT-IN ONE-SHOT READ-ONLY SAVE ATTESTATION
  5. Power off, copy exact marker from OPTIONAL_MARKER to:
       sd:/wiiu/library_profiles/v08/ENABLE-V132-ATTEST.txt
     (bytes are ENABLE-WLP-V132-ATTEST followed by one LF, not CRLF).
  6. Boot once and let Menu load. No special buttons and no new icon needed.
     The Menu displays the existing Wii U/NES profile, NOT the MULTI proposal.
  7. Power OFF. Retrieve from sd:/wiiu/library_profiles/v08/:
       v132-barista-attest.csv
       v132-fixed-icons.csv
     These reports are diagnostic only. They do not reveal Barista contents.

SUCCESS CRITERIA / IMPORTANT LIMITATIONS
 - stage V132, status STRUCTURE_OK
 - account 80000001
 - bytes 130116, fixed_icons 15, folders_empty 60
 - game_slots_used depends on the live save (historically 285)
 - complete valid SHA-256 fingerprints reported
 - redirected_copy_is_active = UNPROVEN always. The specific SD path comes
   from the existing active-profile.cfg serial, not proof of redirection layer.
 - STRUCTURE_OK alone DOES NOT authorize patching or deployment.

PHASE 3: POWERED-OFF PC COPIES (NO SAVE MODIFICATIONS)
  8. With console entirely powered OFF and SD card accessible, take TWO
     independent reads/copies of the BaristaAccountSaveFile.dat reported
     in v132-barista-attest.csv (the report uses fs:/vol/external01; on PC
     this is under sd:/wiiu/homebrew_on_menu_plugin/<serial>/save/80000001/).
     Save them under separate filenames outside SD. Do not copy to live NAND.
  9. Compare their hashes; both must EXACTLY match the attestation CSV.
 10. The bundled PC_ONLY/src/v132_active_save_gate.py validates the copies,
     your previously supplied 511-title game inventory, 277-row v12 preview,
     v111 DB audit, all 60 folders and the paired candidate hashes. It outputs
     only JSON/text, NO .dat/.allowlist or installer. The console-origin claim
     still remains unproven by this step alone.

  Example PC-only command from extracted ZIP root:
    python PC_ONLY/src/v132_active_save_gate.py \
      --first-backup /PC/backups/Barista-copy1.dat \
      --second-backup /PC/backups/Barista-copy2.dat \
      --console-attestation /PC/reports/v132-barista-attest.csv \
      --preview /PC/user-private/v12-preview.csv \
      --inventory /PC/user-private/v10-inventory.csv \
      --audit /PC/user-private/v111-db-audit.csv \
      --game-set-sha256 5EA6DCCD8BA99D13E6FF38E085BA8AA2533C233FAB96817E8751EEA6886746B2 \
      --output /PC/offline-preflight-new

  (Replace /PC paths with real PC directories; output must not exist.)

ROLLBACK
  Power OFF and put back the backed-up working v1.2/v1.1.1 WUPS,
  removing ONLY the new v132 attestation marker. The old v08 profile,
  Barista, WLPA allowlists, and Menu should be unchanged by this build.

NO PAIRED FILE DEPLOYMENT IS INCLUDED OR AUTHORIZED IN THIS RELEASE.
The original v0.8.1 filter still only recognizes profile=wiiu|nes.
A multi-profile switch requires its own deployment design and test.
