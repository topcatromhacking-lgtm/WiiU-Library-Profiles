# v1.3.2 two-file transaction hazard (research / not an installer)

The proposed 277-game Barista layout cannot be activated using only the proven
v0.8.1 `active-profile.cfg`, which supports wiiu/nes. A future `multi`
selection must coordinate a BARISTA SAVE + WLPA allowlist + config + WUPS
plugin. The two filesystem paths cannot be atomically committed together.

## Future transaction invariant

A Wii U boot must NEVER be permitted unless ALL of the following belong to
one verified generation: (1) Barista DAT, (2) WUPS plugin that recognizes
selected profile, (3) WLPA manifest with SHA256 of exact DAT, (4) cfg, and
(5) installed-game set. Files staged under non-active names alone are not a
commit and must not influence the Menu. An incomplete transaction MUST be
reverted by cold console-off SD backup restoration before ANY boot.

There is no deployed transaction tool in this release. A future *manual* test
must be strictly power-off and have a full cold-restoration procedure.

* T0: Known-good v1.2 Menu, normal profile, current Barista. Backups to PC.
* T1: Read-only Menu-side SHA/status then power off completely.
* T2: Independently validate TWO powered-off Barista copies against T1 and
  all user-private v1.2 evidence. No files are installed.
* T3: Build a quarantined candidate pair tied to exact T1 SHA and 277 IDs.
* T4: Independent Barista/WLPA check, C filter acceptance and install-set
  match; if any mismatch, refuse. Still no files are installed.
* T5: Future deployment variant must support `multi` and have a tested
  fail-safe transition/rollback. Not implemented.
* T6: Only after T5, consider a console-off swap of ALL required files as a
  single manually verified logical generation; NEVER power on between swaps.
* T7: After cold boot, validate fixed 15 icons, all 277 game identities,
  Homebrew launch, game launch/return and Menu save retention across boots.
* T8: Any failure => full powered-off rollback of Barista, WLPA, WUPS, cfg
  and optional markers as a single generation. No Menu Sort Aroma use.

If the Menu's Homebrew plugin copies a redirected save from SLC/MLC or silently
rewrites it after a boot, an exact preboot byte pair may become inconsistent.
No automatic self-healing or Barista hot-writes are appropriate without further
hardware evidence.

Upstream Homebrew-on-Menu `SaveRedirection.cpp` copies existing files only
when a redirected target is missing, and replaces `/vol/save/<user>` with a
serial-specific SD folder. A file existing in that folder does not, by itself,
prove redirection was enabled at the moment of the original Menu read.
