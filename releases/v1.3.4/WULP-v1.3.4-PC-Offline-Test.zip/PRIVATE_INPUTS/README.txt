OPTIONAL: Copy the four previously collected private files here.
DO NOT upload this folder to a public repository or share it in GitHub.
See docs/V134_PC_TEST.md. This folder intentionally contains no private data.
